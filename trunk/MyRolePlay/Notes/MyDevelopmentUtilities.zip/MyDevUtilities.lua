----------------------------------------------------------------------------------------------------------
--			LOCALE										--
----------------------------------------------------------------------------------------------------------
if (GetLocale() == "enUS") then
	MDU_LOCALE_MDUDISPLAYMESSAGE_ERROR_NOMESSAGE		= "ERROR: No message entered in function mduDisplayMessage.";
	MDU_LOCALE_MDUDISPLAYMESSAGE_ERROR_MESSAGEWRONGFORMAT	= "ERROR: Message not a string or number in function mduDisplayMessage.";
else
	MDU_LOCALE_MDUDISPLAYMESSAGE_ERROR_NOMESSAGE		= "ERROR: No message entered in function mduDisplayMessage.";
	MDU_LOCALE_MDUDISPLAYMESSAGE_ERROR_MESSAGEWRONGFORMAT	= "ERROR: Message not a string or number in function mduDisplayMessage.";
end


----------------------------------------------------------------------------------------------------------
--			HEADER										--
----------------------------------------------------------------------------------------------------------
MDU_EMPTY_STRING = "";
MDU_DEFULT_MESSAGEOWNER = "MyDevUtilites";

MDU_VERSION = 0.1;

mduColours = { ownerR = 1, ownerG = 0, ownerB = 0, messageR = 1, messageG = 1, messageB = 0 };

MDU_TRUE = 1;
MDU_FALSE = 0;

----------------------------------------------------------
--			FUNCTIONS                       --
----------------------------------------------------------

function mduGenerateNewId(highLimit, lowLimit)
	if (highLimit == nil) then
		highLimit = 99999999;
	end

	if (lowLimit == nil) then
		lowLimit = 1;
	end

	return (math.random(lowLimit, highLimit));
end

function mduGetIndexOfId(t, id)
	for i = 1, table.getn(t) do
		if (t[i].id == id) then
			return (i);
		end
	end
end

function mduDisplayMessage(message, owner, ownerR, ownerG, ownerB, messageR, messageG, messageB)
	if (message == nil) then
		message = MDU_LOCALE_MDUDISPLAYMESSAGE_ERROR_NOMESSAGE;
	else
		if (type(message) ~= "string" and type(message) ~= "number") then
			message = MDU_LOCALE_MDUDISPLAYMESSAGE_ERROR_MESSAGEWRONGFORMAT;
		end
	end

	if (owner == nil) then
		owner = MDU_DEFULT_MESSAGEOWNER;
	end

	if (ownerR == nil) then
		ownerR = mduColours.ownerR;
	end

	if (ownerG == nil) then
		ownerG = mduColours.ownerG;
	end

	if (ownerB == nil) then
		ownerB = mduColours.ownerB;
	end

	if (messageR == nil) then
		messageR = mduColours.messageR;
	end

	if (messageG == nil) then
		messageG = mduColours.messageG;
	end

	if (messageB == nil) then
		messageB = mduColours.messageB;
	end

	if (DEFAULT_CHAT_FRAME) then
		DEFAULT_CHAT_FRAME:AddMessage("|CFF" .. mduColourToHex(ownerR, ownerG, ownerB) .."<" .. owner .. ">|r " .. tostring(message), messageR, messageG, messageB);
	end	
end

function mduColourToHex(r, g, b)
	local red = string.format("%.2X", (r * 255));
	local green = string.format("%.2X", (g * 255));
	local blue = string.format("%.2X", (b * 255));

	local colour = red .. green .. blue;

	return (colour);
end

-- splits the specified text into an array on the specified separator
function string.split( text, separator, limit )
    local parts, position, length, last, jump, count = {}, 1, string.len( text ), nil, string.len( separator ), 0
    while true do
        last = string.find( text, separator, position, true )
        if last and ( not limit or count < limit ) then
            table.insert( parts, string.sub( text, position, last - 1 ) )
            position, count = last + jump, count + 1
        else
            table.insert( parts, string.sub( text, position ) )
            break
        end
    end
    --return unpack( parts )
    return parts;
end
