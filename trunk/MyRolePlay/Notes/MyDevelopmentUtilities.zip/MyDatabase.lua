----------------------------------------------------------------------------------------------------------
--			LOCALE										--
----------------------------------------------------------------------------------------------------------
if (GetLocale() == "enUS") then
	MDB_LOCALE_DATABASEEXISTS_ERROR				= "ERROR: Database already exists: ";
	MDB_LOCALE_DATABASEDOESNOTEXIST_ERROR			= "ERROR: Database does not exist: ";
	MDB_LOCALE_TABLEEXISTS_ERROR				= "ERROR: Table already exists: ";
	MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR			= "ERROR: Table does not exist: ";
	MDB_LOCALE_COLUMNEXISTS_ERROR				= "ERROR: Column already exists: ";
	--MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR			= "ERROR: Table does not exist: ";
	--MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR			= "ERROR: Table does not exist: ";
	--MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR			= "ERROR: Table does not exist: ";
	--MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR			= "ERROR: Table does not exist: ";
	--MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR			= "ERROR: Table does not exist: ";
	--MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR			= "ERROR: Table does not exist: ";
else
	MDB_LOCALE_DATABASEEXISTS_ERROR				= "ERROR: Database already exists: ";
	MDB_LOCALE_DATABASEDOESNOTEXIST_ERROR			= "ERROR: Database does not exist: ";
	MDB_LOCALE_TABLEEXISTS_ERROR				= "ERROR: Table already exists: ";
	MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR			= "ERROR: Table does not exist: ";
	MDB_LOCALE_COLUMNEXISTS_ERROR				= "ERROR: Column already exists: ";
end


----------------------------------------------------------------------------------------------------------
--			HEADER										--
----------------------------------------------------------------------------------------------------------
MDB_NAME = "MyDatabase";
MDB_VERSION = 0.1;

if (not MyDatabase) then
	MyDatabase = {};
end

MyDatabase.Databases = {};

if (not MyDatabase.Saved) then
	MyDatabase.Saved = {};
end

if (not MyDatabase.GlobalSaved) then
	MyDatabase.GlobalSaved = {};
end

MDB_PRIVILAGES_READ = 1;
MDB_PRIVILAGES_WRITE = 2;

--[[
CREATE DATABASE databaseName
REMOVE DATABASE databaseName
RENAME DATABASE databaseName TO newDatabaseName
ALTER DATABASE databaseName (
	CREATE TABLE tableName {(columnName, ...)}
	REMOVE TABLE tableName
	RENAME TABLE tableName TO newTableName
	ALTER TABLE tableName (
		ADD columnName
		REMOVE columnName
		RENAME columnName TO newColumnName
		INSERT (value1, value2, ...)
		DELETE WHERE columnName = $variable | 1|2|3|...  | "string"
		ALTER columnName WHERE dataValue = $variable | 1|2|3|...  | "string" TO newDataValue
	)
)
READ DATABASE databaseName (
	GET columnName, ... FROM tableName TO $variable WHERE dataValue = $variable | 1|2|3|...  | "string"
	SEARCH FOR $data IN columnName FROM tableName SEND TO $variable
)
]]

MDB_SYNTAX_CREATEDATABASE = "CREATE DATABASE";
MDB_SYNTAX_REMOVEDATABASE = "REMOVE DATABASE";
MDB_SYNTAX_RENAMEDATABASE = "RENAME DATABASE";
MDB_SYNTAX_TO = "TO";
MDB_SYNTAX_ALTERDATABASE = "ALTER DATABASE";
MDB_SYNTAX_CREATETABLE = "CREATE TABLE";
MDB_SYNTAX_REMOVETABLE = "REMOVE TABLE";
MDB_SYNTAX_RENAMETABLE = "RENAME TABLE";
MDB_SYNTAX_ALTERTABLE = "ALTER TABLE";
MDB_SYNTAX_ADD = "ADD";
MDB_SYNTAX_REMOVE = "REMOVE";
MDB_SYNTAX_RENAME = "RENAME";
MDB_SYNTAX_INSERT = "INSERT";
MDB_SYNTAX_DELETEWHERE = "DELETE WHERE";
MDB_SYNTAX_ALTER = "ALTER";
MDB_SYNTAX_WHERE = "WHERE";
MDB_SYNTAX_SEARCHFOR = "SEARCH FOR";
MDB_SYNTAX_IN = "IN";
MDB_SYNTAX_FROM = "FROM";
MDB_SYNTAX_GET = "GET";
MDB_SYNTAX_SENDTO = "SEND TO";
MDB_SYNTAX_READDATABASE = "READ DATABASE";

----------------------------------------------------------
--			USER FUNCTIONS                  --
----------------------------------------------------------

function mdbOpenConsole(text)
	for line in string.gfind(text, MDB_SYNTAX_CREATEDATABASE .. "%s+%w+") do
		local databaseName = string.gsub(line, MDB_SYNTAX_CREATEDATABASE .. "%s+", "");

		mdbCreateDatabase(databaseName);
	end

	for line in string.gfind(text, MDB_SYNTAX_ALTERDATABASE .. "%s*%w+%s*%([.]*") do
		local databaseName = string.gsub(line, MDB_SYNTAX_ALTERDATABASE .. "%s*", "");

		mdbCreateTable(databaseName);
	end
end

----------------------------------------------------------
--		BACKEND FUNCTIONS			--
----------------------------------------------------------

function mdbCreateDatabase(databaseName, isSaved, isGlobal)
	if (mdbDatabaseExists(databaseName) == true) then
		mduDisplayMessage(MDB_LOCALE_DATABASEEXISTS_ERROR .. databaseName, MDB_NAME, .8, .8, 0, 1, 0, 0);
			
		return;
	end
	
	if (isSaved == true) then
		if (isGlobal == true) then
			table.insert(MyDatabase.GlobalSaved, databaseName);
			MyDatabase.GlobalSaved[databaseName] = {};

			table.insert(MyDatabase.GlobalSaved[databaseName], Privilages);

			MyDatabase.GlobalSaved[databaseName].Privilages = {};
			MyDatabase.GlobalSaved[databaseName].Privilages.inGuild = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Privilages.guildLeader = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Privilages.inParty = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Privilages.partyLeader = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Privilages.inRaid = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Privilages.raidLeader = MDB_PRIVILAGES_WRITE;

			table.insert(MyDatabase.GlobalSaved[databaseName], Tables);

			MyDatabase.GlobalSaved[databaseName].Tables = {};

			MyDatabase.GlobalSaved[databaseName].isLocked = MDU_FALSE;
		elseif (isGlobal == false) then
			table.insert(MyDatabase.Saved, databaseName);
			MyDatabase.Saved[databaseName] = {};

			table.insert(MyDatabase.Saved[databaseName], Privilages);

			MyDatabase.Saved[databaseName].Privilages = {};
			MyDatabase.Saved[databaseName].Privilages.inGuild = MDB_PRIVILAGES_WRITE;
			MyDatabase.Saved[databaseName].Privilages.guildLeader = MDB_PRIVILAGES_WRITE;
			MyDatabase.Saved[databaseName].Privilages.inParty = MDB_PRIVILAGES_WRITE;
			MyDatabase.Saved[databaseName].Privilages.partyLeader = MDB_PRIVILAGES_WRITE;
			MyDatabase.Saved[databaseName].Privilages.inRaid = MDB_PRIVILAGES_WRITE;
			MyDatabase.Saved[databaseName].Privilages.raidLeader = MDB_PRIVILAGES_WRITE;

			table.insert(MyDatabase.Saved[databaseName], Tables);

			MyDatabase.Saved[databaseName].Tables = {};

			MyDatabase.Saved[databaseName].isLocked = MDU_FALSE;
		end
	else
		table.insert(MyDatabase.Databases, databaseName);
		MyDatabase.Databases[databaseName] = {};

		table.insert(MyDatabase.Databases[databaseName], Privilages);

		MyDatabase.Databases[databaseName].Privilages = {};
		MyDatabase.Databases[databaseName].Privilages.inGuild = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Privilages.guildLeader = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Privilages.inParty = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Privilages.partyLeader = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Privilages.inRaid = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Privilages.raidLeader = MDB_PRIVILAGES_WRITE;

		table.insert(MyDatabase.Databases[databaseName], Tables);

		MyDatabase.Databases[databaseName].Tables = {};

		MyDatabase.Databases[databaseName].isLocked = MDU_FALSE;
	end
	

end

function mdbCreateTable(databaseName, tableName)
	if (mdbDatabaseExists(databaseName) == false) then
		mduDisplayMessage(MDB_LOCALE_DATABASEDOESNOTEXIST_ERROR .. databaseName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end

	if (mdbTableExists(databaseName, tableName) == true) then
		mduDisplayMessage(MDB_LOCALE_TABLEEXISTS_ERROR .. tableName, MDB_NAME, .8, .8, 0, 1, 0, 0);
		
		return;
	end

	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == true) then
		if (isGlobal == true) then
			table.insert(MyDatabase.GlobalSaved[databaseName].Tables, tableName);
			MyDatabase.GlobalSaved[databaseName].Tables[tableName] = {};

			table.insert(MyDatabase.GlobalSaved[databaseName].Tables[tableName], Privilages);

			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Privilages = {};
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Privilages.inGuild = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Privilages.guildLeader = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Privilages.inParty = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Privilages.partyLeader = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Privilages.inRaid = MDB_PRIVILAGES_WRITE;
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Privilages.raidLeader = MDB_PRIVILAGES_WRITE;
		end

		table.insert(MyDatabase.Saved[databaseName].Tables, tableName);
		MyDatabase.Saved[databaseName].Tables[tableName] = {};

		table.insert(MyDatabase.Saved[databaseName].Tables[tableName], Privilages);

		MyDatabase.Saved[databaseName].Tables[tableName].Privilages = {};
		MyDatabase.Saved[databaseName].Tables[tableName].Privilages.inGuild = MDB_PRIVILAGES_WRITE;
		MyDatabase.Saved[databaseName].Tables[tableName].Privilages.guildLeader = MDB_PRIVILAGES_WRITE;
		MyDatabase.Saved[databaseName].Tables[tableName].Privilages.inParty = MDB_PRIVILAGES_WRITE;
		MyDatabase.Saved[databaseName].Tables[tableName].Privilages.partyLeader = MDB_PRIVILAGES_WRITE;
		MyDatabase.Saved[databaseName].Tables[tableName].Privilages.inRaid = MDB_PRIVILAGES_WRITE;
		MyDatabase.Saved[databaseName].Tables[tableName].Privilages.raidLeader = MDB_PRIVILAGES_WRITE;


		table.insert(MyDatabase.Saved[databaseName].Tables[tableName], Columns);

		MyDatabase.Saved[databaseName].Tables[tableName].Columns = {};
	elseif (isSaved == false) then
		table.insert(MyDatabase.Databases[databaseName].Tables, tableName);
		MyDatabase.Databases[databaseName].Tables[tableName] = {};

		table.insert(MyDatabase.Databases[databaseName].Tables[tableName], Privilages);

		MyDatabase.Databases[databaseName].Tables[tableName].Privilages = {};
		MyDatabase.Databases[databaseName].Tables[tableName].Privilages.inGuild = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Tables[tableName].Privilages.guildLeader = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Tables[tableName].Privilages.inParty = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Tables[tableName].Privilages.partyLeader = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Tables[tableName].Privilages.inRaid = MDB_PRIVILAGES_WRITE;
		MyDatabase.Databases[databaseName].Tables[tableName].Privilages.raidLeader = MDB_PRIVILAGES_WRITE;


		table.insert(MyDatabase.Databases[databaseName].Tables[tableName], Columns);

		MyDatabase.Databases[databaseName].Tables[tableName].Columns = {};
	end
end

function mdbDeleteTable(databaseName, tableName)
	
end

function mdbAddColumn(databaseName, tableName, columnName)
	if (mdbDatabaseExists(databaseName) == false) then
		mduDisplayMessage(MDB_LOCALE_DATABASEDOESNOTEXIST_ERROR .. databaseName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end

	if (mdbTableExists(databaseName, tableName) == false) then
		mduDisplayMessage(MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR .. tableName, MDB_NAME, .8, .8, 0, 1, 0, 0);
		
		return;
	end

	if (mdbColumnExists(databaseName, tableName, columnName) == true) then
		mduDisplayMessage(MDB_LOCALE_COLUMNEXISTS_ERROR .. columnName, MDB_NAME, .8, .8, 0, 1, 0, 0);
		
		return;
	end

	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == true) then
		if (isGlobal == true) then
			local tableIterator = table.getn(MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns) + 1;

			table.insert(MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns, tableIterator);
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[tableIterator] = {};
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[tableIterator].name = columnName;
			MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[tableIterator].values = {};
		end

		local tableIterator = table.getn(MyDatabase.Saved[databaseName].Tables[tableName].Columns) + 1;

		table.insert(MyDatabase.Saved[databaseName].Tables[tableName].Columns, tableIterator);
		MyDatabase.Saved[databaseName].Tables[tableName].Columns[tableIterator] = {};
		MyDatabase.Saved[databaseName].Tables[tableName].Columns[tableIterator].name = columnName;
		MyDatabase.Saved[databaseName].Tables[tableName].Columns[tableIterator].values = {};
	elseif (isSaved == false) then
		local tableIterator = table.getn(MyDatabase.Databases[databaseName].Tables[tableName].Columns) + 1;

		table.insert(MyDatabase.Databases[databaseName].Tables[tableName].Columns, tableIterator);
		MyDatabase.Databases[databaseName].Tables[tableName].Columns[tableIterator] = {};
		MyDatabase.Databases[databaseName].Tables[tableName].Columns[tableIterator].name = columnName;
		MyDatabase.Databases[databaseName].Tables[tableName].Columns[tableIterator].values = {};
	end
end
--/script local i, k = gcinfo(); mduDisplayMessage(i .. " --- " .. k);
--/script mdbInsertData("MyRolePlay", "Identification", "test1", "test2", "test3");
function mdbInsertData(databaseName, tableName, ...)
	if (mdbDatabaseExists(databaseName) == false) then
		mduDisplayMessage(MDB_LOCALE_DATABASEDOESNOTEXIST_ERROR .. databaseName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end

	if (mdbTableExists(databaseName, tableName) == false) then
		mduDisplayMessage(MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR .. tableName, MDB_NAME, .8, .8, 0, 1, 0, 0);
		
		return;
	end

	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == true) then
		if (isGlobal == true) then
			local tempIterator = table.getn(MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[1].values) + 1;

			for i = 1, table.getn(MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns) do
				table.insert(MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[i].values, tempIterator);
				MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[i].values[tempIterator] = arg[i];
			end
		end

		local tempIterator = table.getn(MyDatabase.Saved[databaseName].Tables[tableName].Columns[1].values) + 1;

		for i = 1, table.getn(MyDatabase.Saved[databaseName].Tables[tableName].Columns) do
			table.insert(MyDatabase.Saved[databaseName].Tables[tableName].Columns[i].values, tempIterator);
			MyDatabase.Saved[databaseName].Tables[tableName].Columns[i].values[tempIterator] = arg[i];
		end
	elseif (isSaved == false) then
		local tempIterator = table.getn(MyDatabase.Databases[databaseName].Tables[tableName].Columns[1].values) + 1;

		for i = 1, table.getn(MyDatabase.Databases[databaseName].Tables[tableName].Columns) do
			table.insert(MyDatabase.Databases[databaseName].Tables[tableName].Columns[i].values, tempIterator);
			MyDatabase.Databases[databaseName].Tables[tableName].Columns[i].values[tempIterator] = arg[i];
		end
	end
end

function mdbDatabaseExists(databaseName)
	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == true) then
		if (isGlobal == true) then
			if (not MyDatabase.GlobalSaved[databaseName]) then
				return (false);
			end
		end

		if (not MyDatabase.Saved[databaseName]) then
			return (false);
		end
	elseif (isSaved == false) then
		if (not MyDatabase.Databases[databaseName]) then
			return (false);
		end
	end

	return (true);
end

function mdbTableExists(databaseName, tableName)
	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == true) then
		if (isGlobal == true) then
			if (not MyDatabase.GlobalSaved[databaseName].Tables[tableName]) then
				return (false);
			end
		end

		if (not MyDatabase.Saved[databaseName].Tables[tableName]) then
			return (false);
		end
	elseif (isSaved == false) then
		if (not MyDatabase.Databases[databaseName].Tables[tableName]) then
			return (false);
		end
	end

	return (true);
end

function mdbColumnExists(databaseName, tableName, columnName)
	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == true) then
		if (isGlobal == true) then
			for i = 1, table.getn(MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns) do
				if (MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[i].name == columnName) then
					return (true);
				end
			end
		end

		for i = 1, table.getn(MyDatabase.Saved[databaseName].Tables[tableName].Columns) do
			if (MyDatabase.Saved[databaseName].Tables[tableName].Columns[i].name == columnName) then
				return (true);
			end
		end
	elseif (isSaved == false) then
		for i = 1, table.getn(MyDatabase.Databases[databaseName].Tables[tableName].Columns) do
			if (MyDatabase.Databases[databaseName].Tables[tableName].Columns[i].name == columnName) then
				return (true);
			end
		end
	end

	return (false);
end

function mdbIsSaved(databaseName)
	if (MyDatabase.Saved and MyDatabase.Saved[databaseName]) then
		return true, false;
	elseif (MyDatabase.GlobalSaved and MyDatabase.GlobalSaved[databaseName]) then
		return true, true;
	end

	return false, false;
end

function mdbGetColumnIterator(databaseName, tableName, columnName)
	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == true) then
		if (isGlobal == true) then
			for i = 1, table.getn(MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns) do
				if (MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[i].name == columnName) then
					return (i);
				end
			end
		end

		for i = 1, table.getn(MyDatabase.Saved[databaseName].Tables[tableName].Columns) do
			if (MyDatabase.Saved[databaseName].Tables[tableName].Columns[i].name == columnName) then
				return (i);
			end
		end
	elseif (isSaved == false) then
		for i = 1, table.getn(MyDatabase.Databases[databaseName].Tables[tableName].Columns) do
			if (MyDatabase.Databases[databaseName].Tables[tableName].Columns[i].name == columnName) then
				return (i);
			end
		end
	end

	return;
end

function mdbGetNumValues(databaseName, tableName)
	if (mdbDatabaseExists(databaseName) == false) then
		mduDisplayMessage(MDB_LOCALE_DATABASEDOESNOTEXIST_ERROR .. databaseName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end

	if (mdbTableExists(databaseName, tableName) == false) then
		mduDisplayMessage(MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR .. tableName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end

	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == false) then
		if (MyDatabase.Databases[databaseName].Tables[tableName].Columns[1]) then
			return (table.getn(MyDatabase.Databases[databaseName].Tables[tableName].Columns[1].values));
		end
	end
	
	if (isSaved == true) then
		if (isGlobal == true) then
			if (MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[1]) then
				return (table.getn(MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[1].values));
			end
		end

		if (MyDatabase.Saved[databaseName].Tables[tableName].Columns[1]) then
			return (table.getn(MyDatabase.Saved[databaseName].Tables[tableName].Columns[1].values));
		end
	end
end

function mdbCreateColumnPacket(...)
	local result = {};

	for i, columns in ipairs(arg) do
		local newMax = table.getn(result) + 1;
		table.insert(result, newMax, columns);
	end

	return (result);
end

function mdbCreateTablePacket(usingColumn, ...)
	local result = {};

	result.tables = {};
	result.usingColumn = usingColumn;

	for i, tables in ipairs(arg) do
		local newMax = table.getn(result.tables) + 1;
		table.insert(result.tables, newMax, tables);
	end

	return (result);
end

function mdbCreateSearchPacket(column, operator, argument)
	local result = {};

	result.column = column;
	result.operator = operator;
	result.argument = argument;

	return (result);
end

function mdbSearchData(databaseName, tablesWanted, columnsWanted, ...)
	if (mdbDatabaseExists(databaseName) == false) then
		mduDisplayMessage(MDB_LOCALE_DATABASEDOESNOTEXIST_ERROR .. databaseName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end
	
	local result = {};
	local numOfResults = 0;

	local tablesMax = table.getn(tablesWanted.tables);
	local columnsMax = table.getn(columnsWanted);

	if (tablesMax >= 2 and tablesWanted.usingColumn ~= nil) then
		for tableIterator = 2, tablesMax do
			for dataIteratorMain = 1, mdbGetNumValues(databaseName, tablesWanted.tables[1]) do
				for dataIterator = 1, mdbGetNumValues(databaseName, tablesWanted.tables[tableIterator]) do
					local dataMain = mdbGetData(databaseName, tablesWanted.tables[1], tablesWanted.usingColumn, dataIteratorMain);
					local dataSecondary = mdbGetData(databaseName, tablesWanted.tables[tableIterator], tablesWanted.usingColumn, dataIterator);

					if (dataMain == dataSecondary) then
						local isValid = false;

						for i, searches in ipairs(arg) do
							local searchData = mdbGetData(databaseName, tablesWanted.tables[tableIterator], searches.column, dataIterator);
							
							if (searchData or searchData ~= nil) then
								if (searches.operator == "=") then
									if (searchData == searches.argument) then
										isValid = true;
									end
								end
								if (searches.operator == "~=") then
									if (searchData ~= searches.argument) then
										isValid = true;
									end
								end
								if (searches.operator == ">") then
									if (searchData > searches.argument) then
										isValid = true;
									end
								end
								if (searches.operator == "<") then
									if (searchData < searches.argument) then
										isValid = true;
									end
								end
								if (searches.operator == ">=") then
									if (searchData >= searches.argument) then
										isValid = true;
									end
								end
								if (searches.operator == "<=") then
									if (searchData <= searches.argument) then
										isValid = true;
									end
								end
							end
							
						end

						if (isValid == true) then
							
							numOfResults = numOfResults + 1;

							for columnIterator = 1, table.getn(columnsWanted) do
								local tempData = mdbGetData(databaseName, tablesWanted.tables[tableIterator], columnsWanted[columnIterator], dataIterator);

								if (not result[numOfResults]) then
									table.insert(result, numOfResults, {});
								end

								local newMax = table.getn(result[numOfResults]) + 1;
								table.insert(result[numOfResults], newMax, tempData);
							end
						end
					end
				end
			end
		end
	end

	

	return (result);
end

function mdbGetData(databaseName, tableName, columnName, dataIterator)
	if (mdbDatabaseExists(databaseName) == false) then
		mduDisplayMessage(MDB_LOCALE_DATABASEDOESNOTEXIST_ERROR .. databaseName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end

	if (mdbTableExists(databaseName, tableName) == false) then
		mduDisplayMessage(MDB_LOCALE_TABLEDOESNOTEXISTS_ERROR .. tableName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end

	if (mdbColumnExists(databaseName, tableName, columnName) == false) then
		mduDisplayMessage(MDB_LOCALE_COLUMNEXISTS_ERROR .. columnName, MDB_NAME, .8, .8, 0, 1, 0, 0);

		return;
	end

	
	local isSaved, isGlobal = mdbIsSaved(databaseName);

	if (isSaved == false) then
		if (MyDatabase.Databases[databaseName].Tables[tableName].Columns[mdbGetColumnIterator(databaseName, tableName, columnName)].values[dataIterator]) then
			return (MyDatabase.Databases[databaseName].Tables[tableName].Columns[mdbGetColumnIterator(databaseName, tableName, columnName)].values[dataIterator]);
		end
	end
	
	if (isSaved == true) then
		if (isGlobal == true) then
			if (MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[mdbGetColumnIterator(databaseName, tableName, columnName)].values[dataIterator]) then
				return (MyDatabase.GlobalSaved[databaseName].Tables[tableName].Columns[mdbGetColumnIterator(databaseName, tableName, columnName)].values[dataIterator]);
			end
		end

		if (MyDatabase.Saved[databaseName].Tables[tableName].Columns[mdbGetColumnIterator(databaseName, tableName, columnName)].values[dataIterator]) then
			return (MyDatabase.Saved[databaseName].Tables[tableName].Columns[mdbGetColumnIterator(databaseName, tableName, columnName)].values[dataIterator]);
		end
	end
end

--/script mdbTest();
function mdbTest()
	local test = mdbSearchData("MyRolePlayCharacter", mdbCreateTablePacket("profile", "Identification", "Appearance"), mdbCreateColumnPacket("eyeColour", "height"), mdbCreateSearchPacket("eyeColour", "~=", "colour1"), mdbCreateSearchPacket("eyeColour", "=", "colour1"));
	
	for i = 1, table.getn(test) do
		for j = 1, table.getn(test[i]) do
			mduDisplayMessage(test[i][j]);
		end
		mduDisplayMessage("BREAK");
	end
end
